import React, {useState} from 'react';
import '../stylesheets/main.less';
const AddUserForm = (props) => {

    const initUser = {id: null, name: '', gender: '' , age:null};

    const [user, setUser] = useState(initUser);

    const handleChange = e => {
        const {name, value} = e.target;
        setUser({...user, [name]: value});
    }

    const handleSubmit = e => {
        e.preventDefault();
        if (user.name && user.gender && user.age) {
            handleChange(e, props.addUser(user));
        }
    }

    return (
        <form className="form-inline">
            <label><b>Name</b></label>
            <input className="form-control"type="text" value={user.name} name="name" onChange={handleChange} />
            
             <label><b>Gender</b></label>
            <input className="form-control" type="text" value={user.gender} name="gender" onChange={handleChange} />
           
            <label><b>Age</b></label>
            <input className="form-control" type="text" value={user.age} name="age" onChange={handleChange} />
            
            <button className="btn btn-primary" type="submit" onClick={handleSubmit} >Add user</button>
        </form>
    )
}

export default AddUserForm;