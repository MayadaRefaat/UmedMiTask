import React, {useState, useEffect} from 'react';
import '../stylesheets/main.less';
const EditUserForm = (props) => {

    useEffect(() => {
        setUser(props.currentUser)
    }, [props])

    const [user, setUser] = useState(props.currentUser);

    const handleChange = e => {
        const {name, value} = e.target;
        setUser({...user, [name]: value});
        }

    const handleSubmit = e => {
        e.preventDefault();
        if (user.name && user.gender && user.age) props.updateUser(user);
    }

    return (
        <form className="form-inline">
            <label><b>Name</b></label>
            <input className="form-control" type="text" value={user.name} name="name" onChange={handleChange} />
           
            <label><b>Gender</b></label>
            <input className="form-control"type="text" value={user.gender} name="gender" onChange={handleChange} />
           
            <label><b>Age</b></label>
            <input className="form-control"type="text" value={user.age} name="age" onChange={handleChange} />
           
            <button className=" btn btn-primary" type="submit" onClick={handleSubmit} >Edit user</button>
            <button className="btn btn-secondary" type="submit" onClick={() => props.setEditing(false)} >Cancel</button>
        </form>
    )
}

export default EditUserForm;