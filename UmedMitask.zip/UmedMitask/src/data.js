const userList = [
    {
        id: 1,
        name: 'Frank',
        gender:'male',
        age:25

    },
    {
        id: 2,
        name: 'Birgit',
        gender:'female',
        age:30
    }
];

export default userList;