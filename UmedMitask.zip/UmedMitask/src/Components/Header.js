import React from 'react'
import { Link } from 'react-router-dom'

function Haeder() {
    return (
     <div>
         <header id="header" style="background-color: rgb(94, 43, 94); text-emphasis-color: rgb(204, 204, 204); height: 70px;">
      <p style="font-size: 50px; margin: 10px;">
        <img src="ufavicon.ico"/>
      </p>
      </header>
     </div>
    )
}

export default Haeder
