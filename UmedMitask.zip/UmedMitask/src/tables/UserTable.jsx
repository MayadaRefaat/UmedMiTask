import React from 'react';
import '../stylesheets/main.less'
const UserTable = (props) => {
    return (
        <table className="table table-bordered mytable">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Name</th>
                    <th scope="col">Gender</th>
                    <th scope="col">Age</th>
                    <th scope="col">Actions</th>
                </tr>
            </thead>
            <tbody>
                { props.users.length > 0 ? (
                    props.users.map(user => {
                        const {id, name, gender,age} = user;
                        return (
                            <tr key={id}>
                                <td>{id}</td>
                                <td>{name}</td>
                                <td>{gender}</td>
                                <td>{age}</td>
                                <td>
                                    <button className="btn btn-danger" onClick={() => props.deleteUser(id)}> <i class="fas fa-trash-alt"></i>Delete</button>
                                    <button className="btn btn-success" onClick={() => props.editUser(id, user)}><i class="fas fa-edit"></i>Edit</button>
                                </td>
                            </tr>
                        )
                    })
                ) : (
                    <tr>
                        <td colSpan={4}>No users found</td>
                    </tr>
                )   
                }
            </tbody>
        </table>
    )
}

export default UserTable;